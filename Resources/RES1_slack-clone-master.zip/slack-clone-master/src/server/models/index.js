module.exports = {
  User: require('./User'),
  Channel: require('./Channel'),
  Message: require('./Message'),
}
