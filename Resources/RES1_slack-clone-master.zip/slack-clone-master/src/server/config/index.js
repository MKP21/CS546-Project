module.exports = {
  session: {
    secret: 'keyboard cat',
  },
  defaultChannel: 'general',
}
