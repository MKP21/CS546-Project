module.exports = {
  authenticate: 'authenticate',
  join: 'join',
  leave: 'leave',
  msg: 'msg',
  privateMsg: 'privatemsg',
  ownPrivateMsg: 'ownprivatemsg',
  connect: 'connect',
  disconnect: 'disconnect',
  online: 'online',
  offline: 'offline',
  error: 'error',
}
